import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;



public class App extends Application{
	
	//Basically set up the tile field. Set up the width of each "button" of the game, as well as how big it is.
	private static final int TOTAL_TILES = 40;
	private static final int WIDTH = 800;
	private static final int HEIGHT = 600;
	
	private static final int X_COUNT = WIDTH / TOTAL_TILES;
	private static final int Y_COUNT = HEIGHT / TOTAL_TILES;
	
	private Tile[][] grid = new Tile[X_COUNT][Y_COUNT];

	private Stage window;
	
	private DataDisplay scores = new DataDisplay();
	
	
	@Override
	public void start(Stage stage) throws Exception {
		window = stage;
		window.setTitle("Minesweeper Game!");
		

		
		//The actual setup of this design is one gridpane on top, with one grid on the bottom. The gridpane object itself is only ever made once, and scores are tracked as the user plays the game.
		//The actual 'grid' of the game relies on the function createContent(), and is called at the start or whenever the
		VBox layout = new VBox(10);
		
		layout.getChildren().addAll(scores.scoreGrid(), createContent());
		layout.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	private Parent createContent() {
		Pane root = new Pane();
		root.setPrefSize(WIDTH,HEIGHT);
		
		//Generate a tile object for each tile, add it to the grid, and if the math.random generates
		//a value less than .2, it will be a mine
		for(int x = 0; x < X_COUNT; x++) {
			for(int y = 0; y < Y_COUNT; y++) {
				Tile tile = new Tile(x, y, Math.random() < 0.2);
				grid[x][y] = tile;
				root.getChildren().add(tile);
			}
		}
		for(int x = 0; x < X_COUNT; x++) {
			for(int y = 0; y < Y_COUNT; y++) {
				Tile tile = grid[x][y];
				
				//Call getNeighbors to return a list of neighbors. Only count the ones that have
				//bombs in it.
				if(tile.hasBomb){
					continue;
				}
				long bombs = getNeighbors(tile).stream().filter(t -> t.hasBomb).count();
				
				if(bombs > 0) {
					tile.text.setText(String.valueOf(bombs));					
				}
			}
		}
		return root;
	}
	
	//Looks at the neighbors of a given cell and returns all of its neighbors
    private List<Tile> getNeighbors(Tile tile) {
        List<Tile> neighbors = new ArrayList<>();
        
        //
        int[] points = new int[] {
              -1, -1,
              -1, 0,
              -1, 1,
              0, -1,
              0, 1,
              1, -1,
              1, 0,
              1, 1
        };

        for (int i = 0; i < points.length; i++) {
            int dx = points[i];
            int dy = points[++i];

            int newX = tile.x + dx;
            int newY = tile.y + dy;

            //Makes sure that it is grabbing a 'valid' cell, not one that is outside of the grid.
            if (newX >= 0 && newX < X_COUNT
                    && newY >= 0 && newY < Y_COUNT) {
                neighbors.add(grid[newX][newY]);
            }
        }

        return neighbors;
    }
	
	
	
	
	private class Tile extends StackPane {
		private int x, y;
		private boolean hasBomb;
		private int bombs; //Surronding num of bombs
		private boolean isClicked = false;
		
		private Rectangle border = new Rectangle(TOTAL_TILES - 2, TOTAL_TILES - 2);
		
		private Text text = new Text();
		
		public Tile(int x, int y, boolean hasBomb) {
			this.x = x;
			this.y = y;
			this.hasBomb = hasBomb;
			
			text.setText(hasBomb ? "X" : "");
			text.setVisible(false);
			border.setStroke(Color.GREY); //Set border color
			
			getChildren().addAll(border, text);
			
			setTranslateX(x * TOTAL_TILES);
			setTranslateY(y * TOTAL_TILES);
			
			setOnMouseClicked(e -> open());
			
		}
		
		
		//Called when user clicks on a cell. If it is a bomb then it triggers game over screen and asks if the user wants to quit out or start a new round.
		public void open() {
			if(isClicked) {
				return;
			}
			if(hasBomb) {
				scores.addClick();
				if(GameOverBox.display("Game over", "Sorry, but that was a bomb. Would you like to try again?")) {
					reset();
				}else {
					close();
				}
			}
			
			//Track the number of cells that have been clicked.
			scores.addClick();
			scores.addAccurateClick();
			isClicked = true;
			text.setVisible(true);
			border.setFill(null);
			
			
			//Go through each adjacent cell to see if the value of it is 0. If it is, show it.
			if(text.getText().isEmpty()) {
				getNeighbors(this).forEach(Tile :: open);
			}
		}
		
	}
	
	
	//Reset board back to a default state, but keep overall current sessions stats
	private void reset() {
		scores.addGame();
		VBox layout = new VBox(10);
		layout.getChildren().addAll(scores.scoreGrid(), createContent());
		layout.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.show();
	}
	
	//Close out the application
	private void close() {
		window.close();
	}
	
	
	
	

}
