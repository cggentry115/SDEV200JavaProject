import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
public class DataDisplay {
	
	private int clicked = 0;
	private int accurateClicks = 0;
	private int games = 1;
	
	Label totalClicked = new Label("Total Clicked: " + clicked);
	Label totalAccurateClicks = new Label("Accurate Clicks: " + accurateClicks);
	Label totalGames = new Label("Total Games Played: " + games);
	
	
	//public DataDisplay(int clicked, int accurateClicks, int games) {
	//	this.clicked = clicked;
	//	this.accurateClicks = accurateClicks;
	//	this.games = games;
	//}

	public GridPane scoreGrid() {
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10,10,10,10));
		grid.setVgap(8);
		grid.setHgap(30);
		GridPane.setConstraints(totalClicked, 0, 0);
		GridPane.setConstraints(totalAccurateClicks, 1, 0);
		GridPane.setConstraints(totalGames, 2, 0);
		
		grid.getChildren().addAll(totalClicked, totalAccurateClicks, totalGames);
		
		return grid;
	}
	
	
	public void addGame() {
		games += 1;
		totalGames.setText("Total Games Played: " + games);
	}
	public void addClick() {
		clicked += 1;
		totalClicked.setText("Total Clicked: " + clicked);
	}
	public void addAccurateClick() {
		accurateClicks += 1;
		totalAccurateClicks.setText("Accurate Clicks: " + accurateClicks);
	}
	
	

}
